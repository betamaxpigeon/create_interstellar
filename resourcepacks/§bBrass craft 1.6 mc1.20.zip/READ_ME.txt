   __________  _____________   __        ____  ____  __   _____ __ __ ___ 
  / ____/ __ \/ ____/ ____/ | / /       / __ \/ __ \/ /  / ___// //_//   |
 / / __/ /_/ / __/ / __/ /  |/ /       / /_/ / / / / /   \__ \/ ,<  / /| |
/ /_/ / _, _/ /___/ /___/ /|  /       / ____/ /_/ / /______/ / /| |/ ___ |
\____/_/ |_/_____/_____/_/ |_/ ____  /_/    \____/_____/____/_/ |_/_/  |_|
                             /_____/                                    

Create Mod Style Gui
by GREEN_POLSKA

This is custom Minecraft texture pack which was created by me and supporters. 
It includes a variety of changes to the standard textures to make 
more immersive create gaming in Minecraft


Installation: (If you are new at this)

[JAVA]

1) Download the texture pack.
2) Start Minecraft and open the settings.
3) Choose "Resource Packs" and then "Open Resource Pack Folder".
4) Drag the downloaded file into the resource pack folder.
5) In Minecraft select the texture pack from the list of resource packs and click "Done".

[Bedrock editions]

1) Open the Minecraft Bedrock app on your device and sign in to your Xbox Live account.
2) Click on the gear icon in the top left corner to open the "Settings" menu.
3) Select "Resource Packs" from the "Settings" menu.
4) Click on the "Import Resource Pack" button to add the texture pack from your device.
5) Select the added texture pack from the list of available resource packs and click "Select".
6) Restart the game to apply the changes.
7) You should now see the texture pack in your game.


Notes

- Make sure to download the texture pack from a trusted source to ensure the security of your device.
- Please report any bugs or issues in curseforge websie comments so that I can fix them.


Enjoy playing with texture pack! :>



