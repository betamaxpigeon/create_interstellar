# Hey! This script isn't part of the datapack. If you don't know what you're doing, just leave this script alone.
# I left it here if someone else wants to update my datapack. How to use: Unzip tfmg jar file and copy the recipes folder into here, then run the script to make an updated version of the datapack

import os

def process_file(file_path):
    with open(file_path, 'r') as file:
        content = file.read()
    
    if "\"tag\": \"forge:ingots/steel\"" in content:
        new_content = content.replace("\"tag\": \"forge:ingots/steel\"", "\"item\": \"tfmg:steel_ingot\"")
        with open(file_path, 'w') as file:
            file.write(new_content)
    else:
        os.remove(file_path)

def process_directory(directory):
    for root, dirs, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            process_file(file_path)

if __name__ == "__main__":
    process_directory("./recipes")
