---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Meteorite Compass
  icon: meteorite_compass
  position: 410
categories:
- tools
item_ids:
- ae2:meteorite_compass
---

# The Meteorite Compass

<ItemImage id="meteorite_compass" scale="4" />

The Meteorite Compass points at the nearest <ItemLink id="mysterious_cube" />, which thus points it at the nearest
[meteorite](../ae2-mechanics/meteorites.md). It's one of the first AE2 items you should make.

## Recipe

<RecipeFor id="meteorite_compass" />
